from setuptools import setup    


setup(
    name="segunda_pre_entrega_Giorgio"
)